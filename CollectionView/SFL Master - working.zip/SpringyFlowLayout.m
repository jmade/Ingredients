//
//  SpringyFlowLayout.m
//  CollectionView
//
//  Created by Justin Madewell on 10/29/13.
//  Copyright (c) 2013 Justin Madewell. All rights reserved.
//

#import "SpringyFlowLayout.h"
#import "CollectionViewController.h"
#import "TagCollectionViewCell.h"
#import "SKHeaderView.h"
#import "FooterView.h"

@interface SpringyFlowLayout ()

@property (nonatomic, strong) UIDynamicAnimator *dynamicAnimator;

// Needed for tiling
@property (nonatomic, strong) NSMutableSet *visibleIndexPathsSet;
@property (nonatomic, assign) CGFloat latestDelta;
@property (nonatomic, assign) UIInterfaceOrientation interfaceOrientation;

@end


@implementation SpringyFlowLayout
{
    UIDynamicAnimator *_dynamicAnimator;
    
    
    
}


- (void)prepareLayout {
    [super prepareLayout];
    //Set Header & Footer Sizes
    self.headerReferenceSize = CGSizeMake(320, 225);
    self.footerReferenceSize = CGSizeMake(320, 80);
    // Get Content Size
    CGSize contentSize = [self collectionViewContentSize];
    // Header
    NSArray *headerAttributeArray = [super layoutAttributesForElementsInRect:CGRectMake(0, 0, self.headerReferenceSize.width, self.headerReferenceSize.height)];
    _headerAttribs = [headerAttributeArray firstObject];
   // NSLog(@"Header Attribs  %@", _headerAttribs);
    // Cells
    NSArray *cellAttributeArray = [super layoutAttributesForElementsInRect:CGRectMake(0,self.headerReferenceSize.height+1, contentSize.width, contentSize.height-((self.headerReferenceSize.height+1) + (self.footerReferenceSize.height+1)))];
   // NSLog(@"Cell Attribs%@", cellAttributeArray);
    // Footer
    NSArray *footerAttributeArray = [super layoutAttributesForElementsInRect:CGRectMake(0, contentSize.height-self.footerReferenceSize.height, contentSize.width, self.footerReferenceSize.height)];
    _footerAttribs = [footerAttributeArray firstObject];
   // NSLog(@"Footer Attribs  %@", _footerAttribs);
    
    if (!_dynamicAnimator)
    {
        _dynamicAnimator = [[UIDynamicAnimator alloc] initWithCollectionViewLayout:self];
        
        for (UICollectionViewLayoutAttributes *item in cellAttributeArray)
        {
            UIAttachmentBehavior *spring = [[UIAttachmentBehavior alloc] initWithItem:item attachedToAnchor:[item center]];
            //Set Spring Length
            spring.length = 0;
            spring.damping = 0.75;
            spring.frequency = 1.75; //0.8;
            
            [_dynamicAnimator addBehavior:spring];
        }
    }
}


- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    
    UICollectionView *collectionView = [self collectionView];
    UIEdgeInsets insets = [collectionView contentInset];
    CGPoint offset = [collectionView contentOffset];
    CGFloat minY = -insets.top;
    
    
    NSArray *animatedAttributes  = [_dynamicAnimator itemsInRect:rect];
    NSMutableArray *allAttributes = [NSMutableArray arrayWithArray:animatedAttributes];
    [allAttributes addObject:_headerAttribs];
    [allAttributes addObject:_footerAttribs];
    
//    if (offset.y < minY) {
//        
//        CGSize  headerSize = [self headerReferenceSize];
//        CGFloat deltaY = fabsf(offset.y - minY);
//        
//        for (UICollectionViewLayoutAttributes *attrs in allAttributes) {
//            
//            if ([attrs representedElementKind] == UICollectionElementKindSectionHeader) {
//                
//                CGRect headerRect = [attrs frame];
//                headerRect.size.height = MAX(minY, headerSize.height + deltaY);
//                headerRect.origin.y = headerRect.origin.y - deltaY;
//                [attrs setFrame:headerRect];
//                break;
//            }
//        }
//    }

    
    
        
        return allAttributes;
}




-(BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds {
    UIScrollView *scrollView = self.collectionView;
    CGFloat scrollDelta = newBounds.origin.y - scrollView.bounds.origin.y;
    CGPoint touchLocation = [scrollView.panGestureRecognizer locationInView:scrollView];
    
    for (UIAttachmentBehavior *spring in _dynamicAnimator.behaviors) {
        CGPoint anchorPoint = spring.anchorPoint;
        CGFloat distanceFromTouch = fabsf(touchLocation.y - anchorPoint.y);
        CGFloat scrollResistance = distanceFromTouch / 2222; // Change the Back number lower?
        
        
        UICollectionViewLayoutAttributes *item = [spring.items firstObject];
        CGPoint center = item.center;
        center.y += scrollDelta * scrollResistance;
        item.center = center;
        
        [_dynamicAnimator updateItemUsingCurrentState:item];
    }
    
    //Change to YES is performance is bad?
    return NO;
}
@end
